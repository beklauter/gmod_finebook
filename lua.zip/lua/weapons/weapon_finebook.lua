AddCSLuaFile()

SWEP.PrintName = "Steifus Fine Book"
SWEP.Author = "Steifus"
SWEP.Category = "Steifus"
SWEP.Spawnable = true
SWEP.ViewModel = "models/weapons/c_arms_citizen.mdl"
SWEP.WorldModel = ""
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawAmmo = false

function SWEP:Initialize()
    self:SetHoldType("normal")
end

function SWEP:PrimaryAttack()
    local tr = self.Owner:GetEyeTrace()

    if tr.Entity:IsPlayer() and tr.HitPos:Distance(self.Owner:GetShootPos()) <= 100 then
        if SERVER then
            net.Start("OpenFineBookGUI")
            net.WriteEntity(tr.Entity)
            net.Send(self.Owner)
        end

        self:SetNextPrimaryFire(CurTime() + 1)
    end
end

function SWEP:SecondaryAttack() return end