if CLIENT then
   net.Receive("OpenFineBookGUI", function(len)
      local target = net.ReadEntity()
      local ply = LocalPlayer()

      if IsValid(target) then

         local frame = vgui.Create("DFrame")
         frame:SetSize(300, 250)
         frame:SetTitle("Fine Book")
         frame:SetVisible(true)
         frame:MakePopup()
         frame:Center()
         frame:SetDraggable(false)
         frame:ShowCloseButton(false)
         frame.Paint = function(self, w, h)
            surface.SetDrawColor(40, 40, 40, 200)
            surface.DrawRect(0, 0, w, h)
         end

         local label = vgui.Create("DLabel", frame)
         label:SetPos(10, 30)
         label:SetSize(280, 20)
         label:SetText("Grund:")
         label:SetTextColor(Color(255, 255, 255))

         local textbox = vgui.Create("DTextEntry", frame)
         textbox:SetPos(10, 50)
         textbox:SetSize(280, 20)
         textbox:SetText("")
         textbox:SetTextColor(Color(0, 0, 0))
         textbox:SetDrawBackground(true)
         textbox:SetMultiline(false)
         textbox:SetEnterAllowed(false)

         local label2 = vgui.Create("DLabel", frame)
         label2:SetPos(10, 80)
         label2:SetSize(280, 20)
         label2:SetText("Geldbetrag:")
         label2:SetTextColor(Color(255, 255, 255))

         local textbox2 = vgui.Create("DTextEntry", frame)
         textbox2:SetPos(10, 100)
         textbox2:SetSize(280, 20)
         textbox2:SetText("")
         textbox2:SetTextColor(Color(0, 0, 0))
         textbox2:SetDrawBackground(true)
         textbox2:SetMultiline(false)
         textbox2:SetEnterAllowed(false)

         local button = vgui.Create("DButton", frame)
         button:SetText("Rechnung ausstellen")
         button:SetPos(10, 140)
         button:SetSize(280, 30)
         button:SetTextColor(Color(255, 255, 255))
         button:SetFont("DermaDefaultBold")
         button.Paint = function(self, w, h)
            local bgColor = Color(40, 40, 40, 200)

            if self:IsHovered() then
               bgColor = Color(0, 255, 0, 200)
            end

            surface.SetDrawColor(bgColor)
            surface.DrawRect(0, 0, w, h)
         end
         button.DoClick = function()
            local reason = textbox:GetText()
            local amount = tonumber(textbox2:GetText())

            if not reason or reason == "" or not amount or amount <= 0 then
                  Derma_Message("Ungültige Eingabe!", "Fine Book", "OK")
                  return
            end

            net.Start("FineBookDecision")
            net.WriteEntity(target)
            net.WriteString(reason)
            net.WriteFloat(amount)
            net.SendToServer()

            frame:Close()
         end

         local closeButton = vgui.Create("DButton", frame)
         closeButton:SetText("Schließen")
         closeButton:SetPos(10, 190)
         closeButton:SetSize(280, 30)
         closeButton:SetTextColor(Color(255, 255, 255))
         closeButton:SetFont("DermaDefaultBold")
         closeButton.Paint = function(self, w, h)
            local bgColor = Color(40, 40, 40, 200)

            if self:IsHovered() then
               bgColor = Color(255, 0, 0, 200)
            end

            surface.SetDrawColor(bgColor)
            surface.DrawRect(0, 0, w, h)
         end
         closeButton.DoClick = function()
            frame:Close()
         end
      end
   end)
end
