if SERVER then
    util.AddNetworkString("OpenFineBookGUI")
    util.AddNetworkString("FineBookDecision")

    net.Receive("FineBookDecision", function(len, ply)
        local target = net.ReadEntity()
        local reason = net.ReadString()
        local amount = net.ReadFloat()
        if not target:canAfford(amount) then
            target:ChatPrint("Du hast nicht genug Geld um " .. amount .. " zu bezahlen!")
            ply:PrintMessage(HUD_PRINTTALK, "Die Rechnung die ausgestellt wurde konnte nicht bezahlt werden wegen Geldmangel!")
            target:ChatPrint("Du hast " .. abc .. " viele steine!")
            return
        end

        target:addMoney(-amount)
        target:ChatPrint("Du hast eine Strafe in Höhe von $" .. amount .. " für " .. reason .. " bezahlt.")
        ply:addMoney(amount)
        ply:PrintMessage(HUD_PRINTTALK, "Die Rechnung wurde erfolgreich bezahlt!")
    end)
end
